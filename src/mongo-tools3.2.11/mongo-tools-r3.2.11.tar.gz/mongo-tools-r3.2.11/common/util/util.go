// Package util provides commonly used utility functions.
package util
