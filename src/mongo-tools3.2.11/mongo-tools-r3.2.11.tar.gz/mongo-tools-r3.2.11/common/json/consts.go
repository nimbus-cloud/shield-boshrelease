package json

const (
	ArrayStart = '['
	ArraySep   = ','
	ArrayEnd   = ']'
)
