// Package common contains subpackages that are shared amongst the mongo
// tools.
package common
